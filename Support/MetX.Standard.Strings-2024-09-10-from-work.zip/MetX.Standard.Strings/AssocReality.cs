﻿using MetX.Standard.Strings.Generics;

namespace MetX.Standard.Strings;

public class AssocReality : AssocSheet<LongAssocType, AssocSpacetime, VectorAssocType>
{
}