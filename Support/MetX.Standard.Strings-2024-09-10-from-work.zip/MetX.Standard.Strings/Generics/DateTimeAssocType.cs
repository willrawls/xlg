﻿using System;

namespace MetX.Standard.Strings.Generics;

public class DateTimeAssocType : AssocType<DateTime>
{
    public DateTime At { get; set; }
}