﻿using System;
using MetX.Standard.Strings.Generics;

namespace MetX.Standard.Strings;

[Serializable]
public class AssocVerse : AssocSheet<LongAssocType, AssocReality, VectorAssocType>
{

}