XLG - MetX.Standard.XDString
===
Library of classes implementing various forms of associative arrays plus their generics in multiple dimentions (1d-4d included).

