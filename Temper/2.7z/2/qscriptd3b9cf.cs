using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Windows.Forms;
using MetX.Standard.Library;
using MetX.Standard.Pipelines;

namespace MetX.Scripts.Executable
{
    // First script at 2021-09-08 8:11:25 PM
    public static class Program
    {
        public static void Main(string[] args)
        {
            try
            {
                var processor = new QuickScriptProcessor
                {
                    InputFilePath = "",
                    DestinationFilePath =
                        Path.Combine(Path.GetTempPath(), Guid.NewGuid().ToString().Left(13) + ".txt")
                };
                if (args.Length > 0) processor.InputFilePath = args[0];
                if (args.Length > 1) processor.InputFilePath = args[1];

                if (args.Length > 2 && args[2].ToLower() == "open")
                    processor.OpenNotepad = true;

                if (!processor.ReadInput()) return;

                if (!processor.Start()) return;

                for (var number = 0; number < processor.Lines.Count; number++)
                {
                    if (number > 0 && number % 100 == 0) Console.WriteLine("Lines processed: " + number);
                    var line = processor.Lines[number];
                    try
                    {
                        if (!processor.ProcessLine(line, number)) return;
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.ToString());
                        Console.WriteLine("Error processing line " + (number + 1) + ":" + Environment.NewLine +
                                          line + Environment.NewLine +
                                          Environment.NewLine +
                                          "CONTINUE PROCESSING ?");
                        var answer = Console.ReadKey();
                        if (answer.Key.ToString().ToLower() == "n") return;
                    }
                }

                if (!processor.Finish()) return;

                if (processor.Output == null || processor.Output.Length == 0) return;

                if (string.IsNullOrEmpty(processor.DestinationFilePath))
                    processor.DestinationFilePath = "Output.txt";

                File.WriteAllText(processor.DestinationFilePath, processor.Output.ToString());

                if (processor.OpenNotepad)
                    Process.Start(processor.DestinationFilePath);
                //Process.Start("notepad", processor.DestinationFilePath);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
    }

    public class QuickScriptProcessor
    {
        public readonly List<string> Files = new();
        public readonly StreamBuilder Output;
        public readonly StringBuilder OutputStringBuilder = new();
        public string AllText;
        public string DestinationFilePath;
        public string InputFilePath;
        public List<string> Lines = new();
        public bool OpenNotepad;

        public QuickScriptProcessor()
        {
            Output = new StreamBuilder(OutputStringBuilder);
        }


        public bool Start()
        {
            return true;
        }

        public bool ProcessLine(string line, int number)
        {
            if (string.IsNullOrEmpty(line) && number > -1) return true;
            Output.AppendLine(line?.Length < 20
                ? line
                : line[..20]);
            return true;
        }

        public bool Finish()
        {
            return true;
        }

        public bool ReadInput()
        {
            try
            {
                if (string.IsNullOrEmpty(InputFilePath)) InputFilePath = "none";
                Console.WriteLine("Input: " + InputFilePath);
                switch (InputFilePath.ToLower())
                {
                    case "none": // This is the equivalent of reading an empty file
                        AllText = string.Empty;
                        Lines = new List<string> {string.Empty};
                        return true;

                    case "clipboard":
                        AllText = Clipboard.GetText();
                        break;

                    default:
                        if (InputFilePath.IsEmpty())
                        {
                            AllText = "";
                        }
                        if (InputFilePath.StartsWith("http"))
                        {
                            AllText = MetX.Standard.IO.Http.GetUrl(InputFilePath);
                        }
                        else if (!File.Exists(InputFilePath))
                        {
                            Console.WriteLine("Input file missing: " + InputFilePath);
                            return false;
                        }
                        else
                        {
                            switch ((Path.GetExtension(InputFilePath) ?? string.Empty).ToLower())
                            {
                                case "xls":
                                case "xlsx":
                                case ".xls":
                                case ".xlsx":
                                    var inputFile = new FileInfo(InputFilePath);
                                    InputFilePath = inputFile.FullName;
                                /* TODO Find another way to do the Excel thing
                                    Type ExcelType = Type.GetTypeFromProgID("Excel.Application");
                                    dynamic excel = Activator.CreateInstance(ExcelType);
                                    try
                                    {
                                        dynamic workbook = excel.Workbooks.Open(InputFilePath);
                                        sideFile = InputFilePath
                                            .Replace(".xlsx", ".xls")
                                            .Replace(".xls", "_" + DateTime.Now.ToString("G").ToLower()
                                                                           .Replace(":", "")
                                                                           .Replace("/", "")
                                                                           .Replace(":", ""));
                                        Console.WriteLine("Saving Excel as Tab delimited at: " + sideFile + "*.txt");
                                        // 20 = text (tab delimited), 6 = csv
                                        int sheetNumber = 0;
                                        foreach (dynamic worksheet in workbook.Sheets)
                                        {
                                            string worksheetFile = sideFile + "_" + ++sheetNumber + ".txt";
                                            Console.WriteLine("Saving Worksheet " + sheetNumber + " as: " + worksheetFile);
                                            worksheet.SaveAs(worksheetFile, 20, Type.Missing, Type.Missing, false, false, 1);
                                            if (sideFile == null) sideFile = worksheetFile;
                                            Files.Add(worksheetFile);
                                        }
                                        workbook.Close();
                                    }
                                    catch (Exception ex)
                                    {
                                        Console.WriteLine(ex);
                                        return false;
                                    }
                                    excel.Quit();
                                */
                                    AllText = File.ReadAllText(Files[0]);
                                    break;

                                default:
                                    AllText = File.ReadAllText(InputFilePath);
                                    Files.Add(InputFilePath);
                                    break;
                            }
                        }
                        break;
                }
            }
            catch(Exception e)
            {
                Console.WriteLine(e);
                return false;
            }

            if (string.IsNullOrEmpty(AllText))
            {
                Console.WriteLine("Input empty.");
                return false;
            }

            Lines = new List<string>(AllText
                .Replace("\r", string.Empty)
                .Split(new[] { '\n' }, StringSplitOptions
                    .RemoveEmptyEntries));
            return true;
        }

        public static string Ask(string title, string promptText, string defaultValue)
        {
            var value = defaultValue;
            return Ask(title, promptText, ref value) == MessageBoxResult.Cancel
                ? null
                : value;
        }

        public static string Ask(string promptText, string defaultValue = "")
        {
            var value = defaultValue;
            return Ask("ENTER VALUE", promptText, ref value) == MessageBoxResult.Cancel
                ? null
                : value;
        }

        public static MessageBoxResult Ask(string title, string promptText, ref string value)
        {
            if (value == null)
                value = "";

            Console.WriteLine();
            Console.WriteLine($"------[ {title} ]---------------");
            Console.WriteLine();
            Console.WriteLine(promptText);
            Console.WriteLine();
            Console.WriteLine($"    (Enter no value to default to '{value}'");
            Console.WriteLine();
            value = Console.ReadLine().AsString().Trim();
            var messageBoxResult = value.IsNotEmpty()
                ? MessageBoxResult.OK
                : MessageBoxResult.Cancel;
            return messageBoxResult;
        }
    }
}