~~:Finish (wrapper)
